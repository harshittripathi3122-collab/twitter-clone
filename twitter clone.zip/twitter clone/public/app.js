const API_BASE = "/api";

const feedEl = document.getElementById("feed");
const formEl = document.getElementById("tweet-form");
const inputEl = document.getElementById("tweet-input");
const countEl = document.getElementById("char-count");
const buttonEl = document.getElementById("tweet-btn");

function formatTime(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    day: "2-digit",
    month: "short",
  });
}

function renderTweets(tweets) {
  feedEl.innerHTML = "";
  if (!tweets || tweets.length === 0) {
    feedEl.innerHTML = '<div class="empty">No tweets yet. Be the first to post!</div>';
    return;
  }
  for (const t of tweets) {
    const div = document.createElement("article");
    div.className = "tweet";
    div.innerHTML = `
      <p>${escapeHTML(t.content)}</p>
      <time datetime="${t.createdAt}">${formatTime(t.createdAt)}</time>
    `;
    feedEl.appendChild(div);
  }
}

function escapeHTML(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

async function fetchTweets() {
  const res = await fetch(`${API_BASE}/tweets`);
  const data = await res.json();
  renderTweets(data);
}

function connectStream() {
  const es = new EventSource(`${API_BASE}/stream`);
  es.onmessage = (event) => {
    try {
      const tweet = JSON.parse(event.data);
      addTweetToTop(tweet);
    } catch (e) {}
  };
  es.onerror = () => {
    // Try to reconnect after a delay
    setTimeout(() => {
      es.close();
      connectStream();
    }, 3000);
  };
}

function addTweetToTop(tweet) {
  const div = document.createElement("article");
  div.className = "tweet new";
  div.innerHTML = `
    <p>${escapeHTML(tweet.content)}</p>
    <time datetime="${tweet.createdAt}">${formatTime(tweet.createdAt)}</time>
  `;
  feedEl.prepend(div);
}

formEl.addEventListener("submit", async (e) => {
  e.preventDefault();
  const content = inputEl.value.trim();
  if (!content || content.length > 140) return;
  buttonEl.disabled = true;
  try {
    const res = await fetch(`${API_BASE}/tweets`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      alert(err.error || "Failed to post tweet");
    } else {
      inputEl.value = "";
      updateCount();
    }
  } catch (err) {
    alert("Network error");
  } finally {
    buttonEl.disabled = false;
  }
});

inputEl.addEventListener("input", updateCount);

function updateCount() {
  const len = inputEl.value.length;
  countEl.textContent = `${len}/140`;
  countEl.classList.toggle("warn", len >= 120 && len <= 140);
  countEl.classList.toggle("danger", len > 140);
  buttonEl.disabled = len === 0 || len > 140;
}

// Initialize
fetchTweets();
connectStream();
updateCount();